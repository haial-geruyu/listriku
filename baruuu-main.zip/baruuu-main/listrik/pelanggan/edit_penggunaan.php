<?php
session_start();
include '../koneksi.php';
$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM penggunaan WHERE id_penggunaan='$id'"));

if (isset($_POST['update'])) {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $awal = $_POST['meter_awal'];
    $akhir = $_POST['meter_akhir'];

    mysqli_query($koneksi, "UPDATE penggunaan SET bulan='$bulan', tahun='$tahun',
        meter_awal='$awal', meter_akhir='$akhir' WHERE id_penggunaan='$id'");
    header("Location: penggunaan.php");
}
?>

<h2>Edit Penggunaan</h2>
<form method="post">
    Bulan: <input type="text" name="bulan" value="<?= $data['bulan'] ?>"><br>
    Tahun: <input type="text" name="tahun" value="<?= $data['tahun'] ?>"><br>
    Meter Awal: <input type="number" name="meter_awal" value="<?= $data['meter_awal'] ?>"><br>
    Meter Akhir: <input type="number" name="meter_akhir" value="<?= $data['meter_akhir'] ?>"><br>
    <button type="submit" name="update">Update</button>
</form>
