<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'pelanggan') {
    header("Location: ../login.php");
    exit;
}

$id_pelanggan = $_SESSION['id_user'];

// Proses tambah tagihan
if (isset($_POST['tambah'])) {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    
    // Cek duplikat
    $cek = mysqli_query($koneksi, "SELECT * FROM tagihan WHERE id_pelanggan='$id_pelanggan' AND bulan='$bulan' AND tahun='$tahun'");
    if (mysqli_num_rows($cek) == 0) {
        $status = 'Belum Bayar';
        $query_insert = mysqli_query($koneksi, "INSERT INTO tagihan (id_pelanggan, bulan, tahun,  status) VALUES ('$id_pelanggan', '$bulan', '$tahun',  '$status')");
        $pesan = $query_insert ? "Tagihan berhasil ditambahkan." : "Gagal menambahkan tagihan.";
    } else {
        $pesan = "Tagihan untuk bulan dan tahun tersebut sudah ada.";
    }
}

$query = mysqli_query($koneksi, "SELECT * FROM tagihan WHERE id_pelanggan='$id_pelanggan' ORDER BY tahun DESC, bulan DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tagihan Listrik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Tagihan Listrik Anda</h4>
            </div>
            <div class="card-body">

                <!-- Notifikasi -->
                <?php if (isset($pesan)): ?>
                    <div class="alert alert-info"><?= $pesan ?></div>
                <?php endif; ?>

                <!-- Form Tambah Tagihan -->
                <form method="POST" class="mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="bulan" class="form-label">Bulan</label>
                            <select name="bulan" class="form-select" required>
                                <option value="">Pilih Bulan</option>
                                <?php
                                $bulanList = [
                                    'Januari','Februari','Maret','April','Mei','Juni',
                                    'Juli','Agustus','September','Oktober','November','Desember'
                                ];
                                foreach ($bulanList as $bulan) {
                                    echo "<option value=\"$bulan\">$bulan</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="tahun" class="form-label">Tahun</label>
                            <input type="number" name="tahun" class="form-control" min="2020" max="2100" required>
                        </div>
                        
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah Tagihan</button>
                        </div>
                    </div>
                </form>

                <!-- Tabel Tagihan -->
                <table class="table table-bordered table-striped">
                    <thead class="table-secondary">
                        <tr>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Jumlah Meter</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['bulan']) ?></td>
                            <td><?= htmlspecialchars($row['tahun']) ?></td>
                            <td><?= htmlspecialchars($row['jumlah_meter']) ?></td>
                            <td>
                                <span class="badge bg-<?= $row['status'] == 'Lunas' ? 'success' : 'danger' ?>">
                                    <?= $row['status'] ?>
                                </span>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-end">
                <a href="dashboard.php" class="btn btn-secondary">Kembali ke Dashboard</a>
                <a href="../logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>
