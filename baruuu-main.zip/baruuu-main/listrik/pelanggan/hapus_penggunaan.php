<?php
include '../koneksi.php';
$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM penggunaan WHERE id_penggunaan='$id'");
header("Location: penggunaan.php");
