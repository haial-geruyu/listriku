<?php
session_start();
include '../koneksi.php';

if (isset($_POST['simpan'])) {
    $id_pelanggan = $_SESSION['id_user'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $awal = $_POST['meter_awal'];
    $akhir = $_POST['meter_akhir'];

    mysqli_query($koneksi, "INSERT INTO penggunaan (id_pelanggan, bulan, tahun, meter_awal, meter_akhir)
    VALUES ('$id_pelanggan', '$bulan', '$tahun', '$awal', '$akhir')");
    header("Location: penggunaan.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Penggunaan Listrik</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-white shadow-md rounded-lg p-8 w-full max-w-md">
        <h2 class="text-2xl font-semibold mb-6 text-center text-blue-600">Tambah Penggunaan</h2>
        <form method="post" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Bulan</label>
                <input type="text" name="bulan" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Tahun</label>
                <input type="text" name="tahun" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Meter Awal</label>
                <input type="number" name="meter_awal" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Meter Akhir</label>
                <input type="number" name="meter_akhir" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
            </div>
            <div>
                <button type="submit" name="simpan" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md">Simpan</button>
            </div>
        </form>
        <div class="mt-4 text-center">
            <a href="dashboard.php" class="text-sm text-blue-600 hover:underline">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>
