<?php
session_start();
include_once 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Tambah pelanggan
if (isset($_POST['tambah'])) {
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $nomor_kwh = $_POST['nomor_kwh'];
    $id_tarif = $_POST['id_tarif'];

    mysqli_query($koneksi, "INSERT INTO pelanggan (nama_pelanggan, alamat, nomor_kwh, id_tarif) VALUES ('$nama_pelanggan', '$alamat', '$nomor_kwh', '$id_tarif')");
    header("Location: pelanggan.php");
    exit;
}

// Hapus pelanggan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM pelanggan WHERE id_pelanggan=$id");
    header("Location: pelanggan.php");
    exit;
}

// Ambil semua data pelanggan
$pelanggan = mysqli_query($koneksi, "SELECT p.*, t.daya FROM pelanggan p LEFT JOIN tarif t ON p.id_tarif = t.id_tarif");

// Ambil data tarif untuk pilihan dropdown
$tarif = mysqli_query($koneksi, "SELECT * FROM tarif");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Manajemen Pelanggan</h2>

    <form method="POST" class="card p-3 mb-4 shadow-sm">
        <h5>Tambah Pelanggan Baru</h5>
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="nama_pelanggan" class="form-control mb-2" placeholder="Nama Pelanggan" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="alamat" class="form-control mb-2" placeholder="Alamat" required>
            </div>
            <div class="col-md-2">
                <input type="text" name="nomor_kwh" class="form-control mb-2" placeholder="Nomor KWH" required>
            </div>
            <div class="col-md-3">
                <select name="id_tarif" class="form-select mb-2" required>
                    <option value="">Pilih Daya</option>
                    <?php while ($row = mysqli_fetch_assoc($tarif)) : ?>
                        <option value="<?= $row['id_tarif']; ?>"><?= $row['daya']; ?> VA</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" name="tambah" class="btn btn-primary w-100">Tambah</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped shadow-sm bg-white">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>Nomor KWH</th>
                <th>Daya (VA)</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($pelanggan)) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nama_pelanggan']; ?></td>
                <td><?= $row['alamat']; ?></td>
                <td><?= $row['nomor_kwh']; ?></td>
                <td><?= $row['daya']; ?></td>
                <td>
                    <a href="?hapus=<?= $row['id_pelanggan']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../listrik/dashboard_admin.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
</body>
</html>
