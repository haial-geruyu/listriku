<?php
session_start();
include_once 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Tambah penggunaan
if (isset($_POST['tambah'])) {
    $id_pelanggan = $_POST['id_pelanggan'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $meter_awal = $_POST['meter_awal'];
    $meter_akhir = $_POST['meter_akhir'];

    mysqli_query($koneksi, "INSERT INTO penggunaan (id_pelanggan, bulan, tahun, meter_awal, meter_akhir) VALUES ('$id_pelanggan', '$bulan', '$tahun', '$meter_awal', '$meter_akhir')");
    header("Location: penggunaan.php");
    exit;
}

// Hapus penggunaan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    // Hapus data pembayaran terlebih dahulu.
    // Perhatikan: karena subquery mengakses tabel yang juga dihapus, kita bungkus dalam subquery dengan alias.
    $queryPembayaran = "DELETE FROM pembayaran 
                        WHERE id_tagihan IN (
                            SELECT id_tagihan 
                            FROM (SELECT id_tagihan FROM tagihan WHERE id_penggunaan = $id) AS temp
                        )";
    mysqli_query($koneksi, $queryPembayaran);

    // Hapus data tagihan yang terkait dengan penggunaan
    mysqli_query($koneksi, "DELETE FROM tagihan WHERE id_penggunaan = $id");

    // Hapus data penggunaan
    mysqli_query($koneksi, "DELETE FROM penggunaan WHERE id_penggunaan = $id");

    header("Location: penggunaan.php");
    exit;
}

// Ambil data penggunaan
$penggunaan = mysqli_query($koneksi, "SELECT pg.*, pl.nama_pelanggan 
                                       FROM penggunaan pg 
                                       LEFT JOIN pelanggan pl ON pg.id_pelanggan = pl.id_pelanggan");

// Ambil data pelanggan
$pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Penggunaan Listrik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Data Penggunaan Listrik</h2>

    <form method="POST" class="card p-3 mb-4 shadow-sm">
        <h5>Tambah Penggunaan</h5>
        <div class="row">
            <div class="col-md-3">
                <select name="id_pelanggan" class="form-select mb-2" required>
                    <option value="">Pilih Pelanggan</option>
                    <?php while ($row = mysqli_fetch_assoc($pelanggan)) : ?>
                        <option value="<?= $row['id_pelanggan']; ?>"><?= $row['nama_pelanggan']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-1">
                <input type="text" name="bulan" class="form-control mb-2" placeholder="Bulan" required>
            </div>
            <div class="col-md-2">
                <input type="text" name="tahun" class="form-control mb-2" placeholder="Tahun" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="meter_awal" class="form-control mb-2" placeholder="Meter Awal" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="meter_akhir" class="form-control mb-2" placeholder="Meter Akhir" required>
            </div>
            <div class="col-md-2">
                <button type="submit" name="tambah" class="btn btn-primary w-100">Simpan</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped shadow-sm bg-white">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Pelanggan</th>
                <th>Bulan</th>
                <th>Tahun</th>
                <th>Meter Awal</th>
                <th>Meter Akhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($penggunaan)) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nama_pelanggan']; ?></td>
                <td><?= $row['bulan']; ?></td>
                <td><?= $row['tahun']; ?></td>
                <td><?= $row['meter_awal']; ?></td>
                <td><?= $row['meter_akhir']; ?></td>
                <td>
                    <a href="?hapus=<?= $row['id_penggunaan']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../listrik/dashboard_admin.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
</body>
</html>
