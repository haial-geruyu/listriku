<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek di user (admin)
    $query_admin = mysqli_query($koneksi, "SELECT * FROM user 
        JOIN level ON user.id_level = level.id_level 
        WHERE username='$username' AND password='$password'");

    // Cek di pelanggan
    $query_pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan 
        WHERE username='$username' AND password='$password'");

    if ($data = mysqli_fetch_assoc($query_admin)) {
        $_SESSION['id_user'] = $data['id_user'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['level'] = $data['nama_level'];
        header("Location: dashboard_admin.php");

    } elseif ($data = mysqli_fetch_assoc($query_pelanggan)) {
        $_SESSION['id_user'] = $data['id_pelanggan'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['level'] = 'pelanggan';
        header("Location: pelanggan/dashboard.php");

    } else {
        $error = "Login gagal! Username atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0">Form Login</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($error)) { ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php } ?>
                    <form method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="username" id="username" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>

                        <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">© <?= date("Y") ?> Aplikasi Listrik Pascabayar</small>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
