<?php
session_start();
include_once 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Tambah tagihan
if (isset($_POST['tambah'])) {
    $id_pelanggan = $_POST['id_pelanggan'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $jumlah_meter = $_POST['jumlah_meter'];

    mysqli_query($koneksi, "INSERT INTO tagihan (id_pelanggan, bulan, tahun, jumlah_meter, status) VALUES ('$id_pelanggan', '$bulan', '$tahun', '$jumlah_meter', 'Belum Bayar')");
    header("Location: tagihan.php");
    exit;
}

// Hapus tagihan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM tagihan WHERE id_tagihan=$id");
    header("Location: tagihan.php");
    exit;
}

// Ambil data pelanggan untuk dropdown
$pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");

// Ambil semua tagihan + nama pelanggan
$tagihan = mysqli_query($koneksi, "
    SELECT t.*, p.nama_pelanggan, p.nomor_kwh 
    FROM tagihan t 
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan 
    ORDER BY tahun DESC, bulan DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Tagihan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Manajemen Tagihan</h2>

    <form method="POST" class="card p-3 mb-4 shadow-sm">
        <h5>Tambah Tagihan</h5>
        <div class="row">
            <div class="col-md-3">
                <select name="id_pelanggan" class="form-select mb-2" required>
                    <option value="">Pilih Pelanggan</option>
                    <?php while ($row = mysqli_fetch_assoc($pelanggan)) : ?>
                        <option value="<?= $row['id_pelanggan']; ?>">
                            <?= $row['nama_pelanggan']; ?> - <?= $row['nomor_kwh']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="text" name="bulan" class="form-control mb-2" placeholder="Bulan (cth: Juli)" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="tahun" class="form-control mb-2" placeholder="Tahun" required>
            </div>
            <div class="col-md-3">
                <input type="number" name="jumlah_meter" class="form-control mb-2" placeholder="Jumlah Pemakaian (kWh)" required>
            </div>
            <div class="col-md-2">
                <button type="submit" name="tambah" class="btn btn-success w-100">Tambah</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped shadow-sm bg-white">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Nomor KWH</th>
                <th>Bulan</th>
                <th>Tahun</th>
                <th>Jumlah (kWh)</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($tagihan)) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['nama_pelanggan']; ?></td>
                    <td><?= $row['nomor_kwh']; ?></td>
                    <td><?= $row['bulan']; ?></td>
                    <td><?= $row['tahun']; ?></td>
                    <td><?= $row['jumlah_meter']; ?></td>
                    <td><?= $row['status']; ?></td>
                    <td>
                        <a href="?hapus=<?= $row['id_tagihan']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus tagihan ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../listrik/dashboard_admin.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
</body>
</html>
