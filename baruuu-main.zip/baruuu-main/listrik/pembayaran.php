<?php
session_start();
include_once 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Tambah pembayaran
if (isset($_POST['tambah'])) {
    $id_tagihan = $_POST['id_tagihan'];
    $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
    $biaya_admin = $_POST['biaya_admin'];
    $total_bayar = $_POST['total_bayar'];

    mysqli_query($koneksi, "INSERT INTO pembayaran (id_tagihan, tanggal_pembayaran, biaya_admin, total_bayar) VALUES ('$id_tagihan', '$tanggal_pembayaran', '$biaya_admin', '$total_bayar')");
    header("Location: pembayaran.php");
    exit;
}

// Hapus pembayaran
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM pembayaran WHERE id_pembayaran=$id");
    header("Location: pembayaran.php");
    exit;
}

// Ambil semua data pembayaran
$pembayaran = mysqli_query($koneksi, "SELECT pb.*, pl.nama_pelanggan, t.bulan, t.tahun FROM pembayaran pb 
    LEFT JOIN tagihan t ON pb.id_tagihan = t.id_tagihan 
    LEFT JOIN pelanggan pl ON t.id_pelanggan = pl.id_pelanggan");

// Ambil semua tagihan untuk dropdown
$tagihan = mysqli_query($koneksi, "SELECT t.*, pl.nama_pelanggan FROM tagihan t 
    LEFT JOIN pelanggan pl ON t.id_pelanggan = pl.id_pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Manajemen Pembayaran</h2>

    <form method="POST" class="card p-3 mb-4 shadow-sm">
        <h5>Tambah Pembayaran</h5>
        <div class="row">
            <div class="col-md-3">
                <select name="id_tagihan" class="form-select mb-2" required>
                    <option value="">Pilih Tagihan</option>
                    <?php while ($row = mysqli_fetch_assoc($tagihan)) : ?>
                        <option value="<?= $row['id_tagihan']; ?>">
                            <?= $row['nama_pelanggan']; ?> - <?= $row['bulan']; ?>/<?= $row['tahun']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="date" name="tanggal_pembayaran" class="form-control mb-2" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="biaya_admin" class="form-control mb-2" placeholder="Biaya Admin" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="total_bayar" class="form-control mb-2" placeholder="Total Bayar" required>
            </div>
            <div class="col-md-1">
                <button type="submit" name="tambah" class="btn btn-success w-100">Bayar</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped shadow-sm bg-white">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Pelanggan</th>
                <th>Bulan</th>
                <th>Tanggal Bayar</th>
                <th>Biaya Admin</th>
                <th>Total Bayar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($pembayaran)) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nama_pelanggan']; ?></td>
                <td><?= $row['bulan']; ?>/<?= $row['tahun']; ?></td>
                <td><?= $row['tanggal_pembayaran']; ?></td>
                <td><?= $row['biaya_admin']; ?></td>
                <td><?= $row['total_bayar']; ?></td>
                <td>
                    <a href="?hapus=<?= $row['id_pembayaran']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <a href="../listrik/dashboard_admin.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
</body>
</html>
