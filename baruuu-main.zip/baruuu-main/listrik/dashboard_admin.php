<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['level'] != 'admin') {
    header("Location: login.php");
    exit;
}

$jumlah_pelanggan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM pelanggan"))['total'];
$tagihan_belum = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM tagihan WHERE status='Belum Lunas'"))['total'];
$total_pembayaran = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_bayar) AS total FROM pembayaran"))['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <div>
                    <h3>Dashboard Admin</h3>
                    <p>Selamat datang, <strong><?= $_SESSION['username']; ?></strong></p>
                </div>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="p-3 border bg-white rounded shadow-sm">
                            <h5>Total Pelanggan</h5>
                            <p><?= $jumlah_pelanggan; ?> pelanggan</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 border bg-white rounded shadow-sm">
                            <h5>Tagihan Belum Lunas</h5>
                            <p><?= $tagihan_belum; ?> tagihan</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 border bg-white rounded shadow-sm">
                            <h5>Total Pembayaran Masuk</h5>
                            <p>Rp <?= number_format($total_pembayaran, 0, ',', '.'); ?></p>
                        </div>
                    </div>
                </div>

                <h4 class="mt-4 mb-3">Manajemen Data (CRUD)</h4>
                <div class="d-grid gap-2 d-md-block">
                    <a href="pelanggan.php" class="btn btn-outline-primary">Kelola Pelanggan</a>
                    <a href="tagihan.php" class="btn btn-outline-warning">Kelola Tagihan</a>
                    <a href="pembayaran.php" class="btn btn-outline-success">Kelola Pembayaran</a>
                    <a href="penggunaan.php" class="btn btn-outline-info">Kelola Penggunaan</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
